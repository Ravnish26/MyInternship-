package net.javaguides.registration.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.javaguides.registration.model.Intern;

public class InternDao {

    public int InternRegistration( Intern intern) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO internfortnightreport" +
            "  (name, date, report_no, enroll_no, date_from, date_to, duration, industry_name, external_mentor, external_mob, external_email, internal_mentor, internal_mob, internal_email, mainpoint) VALUES " +
            " (?, ?, ?, ?, ?,?,?,?, ?, ?, ?, ?,?,?,?);";

        int result = 0;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/mysql_database?useSSL=false", "root", "Tanveer@89820");

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            
            preparedStatement.setString(1, intern.getName());
            preparedStatement.setString(2, intern.getDate());
            preparedStatement.setString(3, intern.getReport_no());
            preparedStatement.setString(4, intern.getEnroll_no());
            preparedStatement.setString(5, intern.getDate_from());
            preparedStatement.setString(6, intern.getDate_to());
            preparedStatement.setString(7, intern.getDuration());
            preparedStatement.setString(8, intern.getIndustry_name());
            preparedStatement.setString(9, intern.getExternal_mentor());
            preparedStatement.setString(10, intern.getExternal_mob());
            preparedStatement.setString(11, intern.getExternal_email());
            preparedStatement.setString(12, intern.getInternal_mentor());
            preparedStatement.setString(13, intern.getInternal_mob());
            preparedStatement.setString(14, intern.getInternal_email());
            preparedStatement.setString(15, intern.getMainpoint());


            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return result;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}

package net.javaguides.registration.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import net.javaguides.registration.dao.InternDao;
import net.javaguides.registration.model.Intern;
/**
 * Servlet implementation class InternServlet
 */
@WebServlet("/InternServlet")
public class InternServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String Intern_Fortnight_Report = null;
	
	private InternDao internDao = new InternDao(); 
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InternServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String date = request.getParameter("date");
		String report_no = request.getParameter("report_no");
		String enroll_no = request.getParameter("enroll_no");
		String date_from = request.getParameter("date_from");
		String date_to = request.getParameter("date_to");
		String duration = request.getParameter("duration");
		String industry_name = request.getParameter("industry_name_address");
		String external_mentor = request.getParameter("external_mentor");
		String external_mob = request.getParameter("external_mob");
		String external_email = request.getParameter("external_email");
		String internal_mentor = request.getParameter("internal_mentor");
		String internal_mob = request.getParameter("internal_mob");
		String internal_email = request.getParameter("internal_email");
		String mainpoint = request.getParameter("mainpoint");
		
		Intern intern = new Intern();
		intern.setName(name);
		intern.setDate(date);
		intern.setReport_no(report_no);
		intern.setEnroll_no(enroll_no);
		intern.setDate_from(date_from);
		intern.setDate_to(date_to);
		intern.setDuration(duration);
		intern.setIndustry_name(industry_name);
		intern.setExternal_mentor(external_mentor);
		intern.setExternal_mob(external_mob);
		intern.setExternal_email(external_email);
		intern.setInternal_mentor(internal_mentor);
		intern.setInternal_mob(internal_mentor);
		intern.setInternal_email(internal_mentor);
		intern.setMainpoint(mainpoint);
		
		try {
			internDao.InternRegistration(intern);
		
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		response.sendRedirect("afterwards.jsp");
	}

}

package net.javaguides.registration.model;

public class Intern {
	
	
	private String name;
	private String date;
	private String report_no;
	private String enroll_no;
	private String date_from;
	private String date_to;
	private String duration;
	private String industry_name;
	private String external_mentor;
	private String external_mob;
	private String external_email;
	private String internal_mentor;
	private String internal_mob;
	private String internal_email;
	private String mainpoint;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getReport_no() {
		return report_no;
	}
	public void setReport_no(String report_no) {
		this.report_no = report_no;
	}
	public String getEnroll_no() {
		return enroll_no;
	}
	public void setEnroll_no(String enroll_no) {
		this.enroll_no = enroll_no;
	}
	public String getDate_from() {
		return date_from;
	}
	public void setDate_from(String date_from) {
		this.date_from = date_from;
	}
	public String getDate_to() {
		return date_to;
	}
	public void setDate_to(String date_to) {
		this.date_to = date_to;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getIndustry_name() {
		return industry_name;
	}
	public void setIndustry_name(String industry_name) {
		this.industry_name = industry_name;
	}
	public String getExternal_mentor() {
		return external_mentor;
	}
	public void setExternal_mentor(String external_mentor) {
		this.external_mentor = external_mentor;
	}
	public String getExternal_mob() {
		return external_mob;
	}
	public void setExternal_mob(String external_mob) {
		this.external_mob = external_mob;
	}
	public String getExternal_email() {
		return external_email;
	}
	public void setExternal_email(String external_email) {
		this.external_email = external_email;
	}
	public String getInternal_mentor() {
		return internal_mentor;
	}
	public void setInternal_mentor(String internal_mentor) {
		this.internal_mentor = internal_mentor;
	}
	public String getInternal_mob() {
		return internal_mob;
	}
	public void setInternal_mob(String internal_mob) {
		this.internal_mob = internal_mob;
	}
	public String getInternal_email() {
		return internal_email;
	}
	public void setInternal_email(String internal_email) {
		this.internal_email = internal_email;
	}
	public String getMainpoint() {
		return mainpoint;
	}
	public void setMainpoint(String mainpoint) {
		this.mainpoint = mainpoint;
	}


	

}

package discussBlog.Util;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import discussBlog.Dao.LoginDao;
import discussBlog.Model.User;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uemail = request.getParameter("uemail");
		String upass = request.getParameter("upass");
		
		LoginDao dao = new LoginDao();
		if(dao.loginCheck(uemail, upass)) {
			
			HttpSession session = request.getSession();
			
			User user = dao.getUser(uemail, upass);
			int userID = user.userID;
			session.setAttribute("userID", userID);
			session.setAttribute("user", user);
			response.sendRedirect("Home.jsp");
			
		}
		else {
			String st = "Invalid";
			response.sendRedirect("Login.jsp?invalid=" + st);
		}
		
	}

}

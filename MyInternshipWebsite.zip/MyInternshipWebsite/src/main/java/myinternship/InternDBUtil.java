package myinternship;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class InternDBUtil {
	 public static void registerIntern(Intern Lat_Sub_registration) throws ClassNotFoundException {
		        String INSERT_USERS_SQL = "INSERT INTO Lat_Sub_registration" +
		            "  (enroll_no, name, section, reason, internal_mentor, class_teacher, coordinator, HOD) VALUES " +
		            " (?, ?, ?, ?, ?, ?, ?, ?);";

		        Class.forName("com.mysql.jdbc.Driver");

		        try (java.sql.Connection connection = DriverManager
		            .getConnection("jdbc:mysql://localhost:3306/java?autoReconnect=true&useSSL=false", "root", "Tanveer@89820");

		            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
		            preparedStatement.setString(1, Lat_Sub_registration.getEnroll_no());
		            preparedStatement.setString(2, Lat_Sub_registration.getName());
		            preparedStatement.setString(3, Lat_Sub_registration.getSection());
		            preparedStatement.setString(4, Lat_Sub_registration.getReason());
		            preparedStatement.setString(5, Lat_Sub_registration.getInternal_mentor());
		            preparedStatement.setString(6, Lat_Sub_registration.getClass_teacher());
		            preparedStatement.setString(7, Lat_Sub_registration.getCoordinator());
		            preparedStatement.setString(8, Lat_Sub_registration.getHOD());
		           // preparedStatement.setBlob(9, Lat_Sub_registration.getScreenshot());
		            
		            preparedStatement.executeUpdate();
		            
		}
		        catch (SQLException e) {
		            printSQLException(e);
		        }
		    }
			private static void printSQLException(SQLException ex) {
		        for (Throwable e: ex) {
		            if (e instanceof SQLException) {
		                e.printStackTrace(System.err);
		                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
		                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
		                System.err.println("Message: " + e.getMessage());
		                Throwable t = ex.getCause();
		                while (t != null) {
		                    System.out.println("Cause: " + t);
		                    t = t.getCause();
		                }
		            }
		        }
		    }
		}


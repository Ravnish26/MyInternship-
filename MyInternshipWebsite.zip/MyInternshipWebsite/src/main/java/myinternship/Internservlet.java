package myinternship;

import java.io.IOException;
import java.sql.Blob;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import myinternship.Intern;
import myinternship.InternDBUtil;

@WebServlet("/Internservlet")
@MultipartConfig(
        fileSizeThreshold = 1024 * 10,  // 10 KB
        maxFileSize = 1024 * 300,       // 300 KB
        maxRequestSize = 1024 * 1024    // 1 MB 
)
public class Internservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init() {
        new InternDBUtil();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String EnrollNo= request.getParameter("enrollNum");
	     String Name= request.getParameter("internName");
	     String Section= request.getParameter("section");
	     String Reason= request.getParameter("reason");
	     String InternalMentor= request.getParameter("internalMentor");
	     String ClassTeacher= request.getParameter("classTeacher");
	     String Coordinator= request.getParameter("coordinator");
	     String HOD= request.getParameter("HOD");
	     // Blob Screenshot= (Blob) request.getPart("Screenshot");

	        Intern Lat_Sub_registration = new Intern();
	        Lat_Sub_registration.setEnroll_no(EnrollNo);
	        Lat_Sub_registration.setName(Name);
	        Lat_Sub_registration.setSection(Section);
	        Lat_Sub_registration.setReason(Reason);
	        Lat_Sub_registration.setInternal_mentor(InternalMentor);
	        Lat_Sub_registration.setClass_teacher(ClassTeacher);
	        Lat_Sub_registration.setCoordinator(Coordinator);
	        Lat_Sub_registration.setHOD(HOD);
	        //Lat_Sub_registration.setScreenshot(Screenshot);
	        
	        try {
	            InternDBUtil.registerIntern(Lat_Sub_registration);
	            response.sendRedirect(request.getContextPath() + "/message.jsp");
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	}
}
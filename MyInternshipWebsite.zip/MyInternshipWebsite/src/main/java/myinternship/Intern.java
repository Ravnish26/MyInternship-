package myinternship;

import java.sql.Blob;

public class Intern {
	private String enroll_no;    
    private String name;
    private String section;
    private String reason;
    private String internal_mentor;
    private String class_teacher;
    private String coordinator;
    private String HOD;
    private Blob screenshot;
    public String getEnroll_no() {
		return enroll_no;
	}
	public void setEnroll_no(String enroll_no) {
		this.enroll_no = enroll_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getInternal_mentor() {
		return internal_mentor;
	}
	public void setInternal_mentor(String internal_mentor) {
		this.internal_mentor = internal_mentor;
	}
	public String getClass_teacher() {
		return class_teacher;
	}
	public void setClass_teacher(String class_teacher) {
		this.class_teacher = class_teacher;
	}
	public String getCoordinator() {
		return coordinator;
	}
	public void setCoordinator(String coodinator) {
		this.coordinator = coodinator;
	}
	public Blob getScreenshot() {
		return screenshot;
	}
	public void setScreenshot(Blob screenshot) {
		this.screenshot = screenshot;
	}
	public String getHOD() {
		return HOD;
	}
	public void setHOD(String hOD) {
		HOD = hOD;
	}
	
}
